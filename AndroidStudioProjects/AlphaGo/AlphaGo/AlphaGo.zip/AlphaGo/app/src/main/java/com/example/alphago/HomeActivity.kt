package com.example.alphago

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.miapp.PerfilActivity

class HomeActivity : AppCompatActivity() {

    private lateinit var  button_comienza:Button

    override fun onCreate(saveInstanceState: Bundle?) {
        super.onCreate(saveInstanceState)
        setContentView(R.layout.activity_home)

        fun validarFormulario(): Boolean {
            //  validaciones de los campos del formulario
            return true // Devuelve true si el formulario es válido, false si no
        }

        button_comienza=findViewById(R.id.tv_registrate)

        button_comienza.setOnClickListener {
            if (validarFormulario()) {
                Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, HomeActivity::class.java)
                startActivity(intent)
                finish()
            }
        }

        }

    }

